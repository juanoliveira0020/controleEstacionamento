package com.estacionamento.controle.service;
/* camada de serviço onde a lógica de negócio acontece.
* */

import com.estacionamento.controle.model.Veiculos;
import com.estacionamento.controle.repository.VeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/* anotação que marca esta classe como um componente de serviço*/
@Service

public class VeiculoService {
    @Autowired
    private VeiculoRepository repository;

    public Veiculos registrarVeiculo(Veiculos veiculos){
        veiculos.setEntrada(LocalDateTime.now());
        return repository.save(veiculos);
    }

    public  Veiculos registrarSaida(Long id){
        Optional<Veiculos> veiculoOptional= repository.findById(id);
        if (veiculoOptional.isPresent()){
            Veiculos veiculo = veiculoOptional.get();
            veiculo.setSaida(LocalDateTime.now());
            veiculo.calcularValor();
            return repository.save(veiculo);
        }
        throw new RuntimeException(("Veiculo não encontrado"));
    }
    public List<Veiculos> listarVeiculos(){
        return repository.findAll();
    }
}
