package com.estacionamento.controle.repository;

import com.estacionamento.controle.model.Veiculos;
import org.springframework.data.jpa.repository.JpaRepository;
public interface VeiculoRepository extends  JpaRepository<Veiculos,Long> {
}
