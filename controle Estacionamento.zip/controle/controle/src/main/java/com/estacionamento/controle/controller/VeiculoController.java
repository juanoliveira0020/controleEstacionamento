package com.estacionamento.controle.controller;

import com.estacionamento.controle.model.Veiculos;
import com.estacionamento.controle.service.VeiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/veiculos")

public class VeiculoController{
    @Autowired
    private VeiculoService service;


    @PostMapping("/entrada")

    public ResponseEntity<Veiculos> registrarVeiculo(@RequestBody Veiculos veiculo){
        veiculo.setValorPorHora(25.00); // Define o valor por hora de entrada
        Veiculos veiculoRegistrado = service.registrarVeiculo(veiculo);
        return new ResponseEntity<>(veiculoRegistrado,HttpStatus.CREATED);
    }

    @PutMapping("/saida/{id}")
    public ResponseEntity<Veiculos> registrarSaida(@PathVariable Long id, @RequestBody Veiculos veiculo) {
        try {
            Veiculos veiculoSaida = service.registrarSaida(id);
            return new ResponseEntity<>(veiculoSaida, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

@GetMapping
public ResponseEntity<List<Veiculos>> listarVeiculs(){
        List<Veiculos> veiculos = service.listarVeiculos();
        return new ResponseEntity<>(veiculos, HttpStatus.OK);
}
}

