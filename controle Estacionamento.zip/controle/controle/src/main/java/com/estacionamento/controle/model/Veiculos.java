package com.estacionamento.controle.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.time.Duration;
import java.time.LocalDateTime;


@Entity

public class Veiculos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String placa;
    private LocalDateTime entrada;
    private LocalDateTime saida;
    private double valorPorHora;
    private Integer tempoPermanecido; // em minutos ou horas
    private Double valorTotal;

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public LocalDateTime getEntrada() {
        return entrada;
    }

    public void setEntrada(LocalDateTime entrada) {
        this.entrada = entrada;
    }

    public LocalDateTime getSaida() {
        return saida;
    }

    public void setSaida(LocalDateTime saida) {
        this.saida = saida;
    }

    public double getValorPorHora() {
        return valorPorHora;
    }

    public void setValorPorHora(double valorPorHora) {
        this.valorPorHora = valorPorHora;
    }

    public Integer getTempoPermanecido() {
        return tempoPermanecido;
    }

    public void setTempoPermanecido(Integer tempoPermanecido) {
        this.tempoPermanecido = tempoPermanecido;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    // Método para calcular valor total com base na entrada, saída e valor/hora
    public void calcularValor() {
        if (entrada != null && saida != null && valorPorHora > 0) {
            long minutos = Duration.between(entrada, saida).toMinutes();
            this.tempoPermanecido = (int) minutos;
            double horas = minutos / 60.0;
            this.valorTotal = horas * valorPorHora;
        }
    }
}
